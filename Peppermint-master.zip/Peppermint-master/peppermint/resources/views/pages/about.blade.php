@extends('master-template')

@section('content')

<h1>About Me: {{ $first }} {{ $last }}</h1>
<p>A bunch of stuff goes here</p>

@stop