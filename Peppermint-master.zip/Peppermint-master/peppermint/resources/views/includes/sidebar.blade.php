<div id="sidebar">
    <ul class="nav nav-stacked">
        <li role="presentation" class="active"><a href="/">Dashboard</a></li>
        <li role="presentation" class="active"><a href="/employees">Employees</a></li>
        <li role="presentation"><a href="#">Finances</a></li>
            <li role="presentation" class="indent"><a href="#">Expenditures</a></li>
                <li role="presentation" class="indent2"><a href="/finances/expenditures/supplies">Supplies</a></li>
                <li role="presentation" class="indent2"><a href="/finances/expenditures/employees">Employees</a></li>

            <li role="presentation" class="indent"><a href="/finances/invoices">Invoices</a></li>
    </ul>
</div>